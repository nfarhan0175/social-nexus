package com.example.nexus;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class account extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_settings);

        // Additional setup if needed
    }
}
